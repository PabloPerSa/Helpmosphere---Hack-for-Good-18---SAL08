import csv

def openFile():
    with open('Datos_finales.csv', newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=';', quotechar='"')
        for row in spamreader:
            with open('datos_finales.txt', 'a') as myfile:
                wr = csv.writer(myfile, delimiter=':',
                                quotechar='"',
                                quoting=csv.QUOTE_ALL)
                wr.writerow(row)
                myfile.close()
    return

openFile()
