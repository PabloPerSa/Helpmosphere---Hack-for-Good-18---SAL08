import csv
import pandas as pd

#Une los datos

trafico = pd.read_csv('Datos_trafico_depurados.csv')
clima = pd.read_excel('datosretirocompletos.xlsx')

clima.fecha = [str(fecha.date()) for fecha in clima.fecha]

UNION = pd.merge(clima,trafico ,how='inner', on='fecha').reset_index(drop=True)
UNION.to_csv('Datos_finales.csv')
