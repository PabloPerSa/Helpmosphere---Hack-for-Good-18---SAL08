import csv, operator

#La estación que queremos buscar es la 4063
def openFile():
    #Se cambia la fecha manualmente
    with open('12-2015.csv', newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=';', quotechar='"')
        for row in spamreader:
            #Imprime en un nuevo documento las columnas deseadas
            debugged=[row[0],row[1],row[4],row[5],row[6],row[7]]
            #print (debugged)
            if(debugged[0] == '4063'):
                with open('12-2015Depurado.csv', 'a') as myfile:
                    wr = csv.writer(myfile, delimiter=':',
                                    quotechar='"',
                                    quoting=csv.QUOTE_ALL)
                    wr.writerow(depurada)
                    myfile.close()
                with open('datos.csv', 'a') as myfile:
                    wr = csv.writer(myfile, delimiter=':',
                                    quotechar='"',
                                    quoting=csv.QUOTE_ALL)
                    wr.writerow(debugged)
                    myfile.close()
    return

openFile()
