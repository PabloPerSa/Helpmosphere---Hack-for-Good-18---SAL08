import csv, operator

#Este script une los datos de cada año en un único archivo .csv

def openFile():
    with open('datos2017.csv', newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=':', quotechar='"')
        for row in spamreader:
            with open('datos.csv', 'a') as myfile:
                wr = csv.writer(myfile, delimiter=':',
                                quotechar='"',
                                quoting=csv.QUOTE_ALL)
                wr.writerow(row)
                myfile.close()
    return

openFile()
