import os
os.remove('datos.csv')
