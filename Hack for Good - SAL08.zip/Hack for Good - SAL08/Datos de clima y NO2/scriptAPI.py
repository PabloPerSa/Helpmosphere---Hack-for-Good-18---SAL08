import http.client
import ssl
import json
import pandas as pd
import datetime
import requests
import csv
import time
from datetime import timedelta, date


def imprimirFecha():
    pos=0
    listaFechas=[]
    
    start_date = date(2015, 1, 1)
    end_date = date(2015, 1, 5)
    for data in daterange(start_date, end_date):
        fecha = data.strftime("%Y-%m-%d")
        pos+=1
        listaFechas.append(fecha)
    return listaFechas, pos

def daterange(start_date, end_date):
    for n in range(int ((end_date - start_date).days)):
        yield start_date + timedelta(n)


def GetData(fecha, idst, conn):
    headers = {
    'cache-control': "no-cache"
    }
    
    conn.request("GET", f"/opendata/api/valores/climatologicos/diarios/datos/fechaini/{fecha}T00:00:00UTC/fechafin/{fecha}T23:59:59UTC/estacion/{idst}/?api_key=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJwYWJsb3BzMTFAdXNhbC5lcyIsImp0aSI6ImMyMGY1MWQ1LTE2Y2ItNDQxYy05ZmExLTQ4MmE4NzBkMTM3YyIsImlzcyI6IkFFTUVUIiwiaWF0IjoxNTE5ODMwOTU4LCJ1c2VySWQiOiJjMjBmNTFkNS0xNmNiLTQ0MWMtOWZhMS00ODJhODcwZDEzN2MiLCJyb2xlIjoiIn0.r_PN4AJdmGkJ9wKwTReUqiyTNYkUM29m-icuiwBxmYQ", headers=headers, )
    res = conn.getresponse()
    data = res.read().decode('utf-8','ignore')
    data = json.loads(data)

    conn.request("GET", data['datos'], headers=headers, )
    res= conn.getresponse()
    datos = res.read().decode('utf-8','ignore')
    datos= json.loads(datos)[0]
    
    return datos


def writeFile(lista):
    with open('datosPrueba.csv', 'a') as myfile:
        wr = csv.writer(myfile, delimiter=':',
                        quotechar='"',
                        quoting=csv.QUOTE_ALL)
        wr.writerow(lista)
    myfile.close()
    return


apyKey='eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJwYWJsb3BzMTFAdXNhbC5lcyIsImp0aSI6ImMyMGY1MWQ1LTE2Y2ItNDQxYy05ZmExLTQ4MmE4NzBkMTM3YyIsImlzcyI6IkFFTUVUIiwiaWF0IjoxNTE5ODMwOTU4LCJ1c2VySWQiOiJjMjBmNTFkNS0xNmNiLTQ0MWMtOWZhMS00ODJhODcwZDEzN2MiLCJyb2xlIjoiIn0.r_PN4AJdmGkJ9wKwTReUqiyTNYkUM29m-icuiwBxmYQ'
context = ssl.create_default_context()
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE
conn = http.client.HTTPSConnection("opendata.aemet.es", context = context)

headers = {
    'cache-control': "no-cache"
    }


conn.request("GET", f"/opendata/api/valores/climatologicos/diarios/datos/fechaini/2018-01-26T00:00:00UTC/fechafin/2018-01-26T23:59:59UTC/estacion/3194U/?api_key={apyKey}", headers=headers, )

res = conn.getresponse()
data = res.read().decode('utf-8','ignore')
data = json.loads(data)

conn.request("GET", data['datos'], headers=headers, )
res= conn.getresponse()
datos = res.read().decode('utf-8','ignore')
datos= json.loads(datos)


lista_de_fechas = imprimirFecha()[0]

i=0
nFechas=imprimirFecha()[1]

print ("Vas a recoger los datos de " + str(nFechas) + " dias")

while (i < nFechas):
    h = GetData(lista_de_fechas[i], '3129', conn)
    time.sleep(2)
    lista = list(h.values())
    i+=1
    writeFile(lista)
